ENT.Type = "anim"

ENT.IsStatus = true

function ENT:OnInitialize()
end

function ENT:PhysicsCollide(data, physobj)
end

function ENT:StartTouch(ent)
end

function ENT:Touch(ent)
end

function ENT:EndTouch(ent)
end

function ENT:AcceptInput(name, activator, caller)
end

ENT.GetPlayer = ENT.GetParent