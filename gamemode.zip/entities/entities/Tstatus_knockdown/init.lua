AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")


function ENT:SetDie(fTime)
	if fTime == 0 or not fTime then
		self.DieTime = 0
	elseif fTime == -1 then
		self.DieTime = 999999999
	else
		self.DieTime = CurTime() + fTime
		self:SetDuration(fTime)
	end
end

function ENT:PlayerSet(pPlayer, bExists)
	self:SetStartTime(CurTime())

	pPlayer.KnockedDown = self

	pPlayer.JumpHeight = pPlayer:GetJumpPower()
	pPlayer:SetJumpPower(0)

	pPlayer:DrawWorldModel(false)
	pPlayer:DrawViewModel(false)

	local lifetime = self.DieTime - CurTime()
	self.DieTime = CurTime() + lifetime
	self:SetDTFloat(1, self.DieTime)

	if not bExists then
		pPlayer:CreateRagdoll()
	end
end

function ENT:OnRemove()
	local parent = self:GetParent()
	if parent:IsValid() then
		parent.KnockedDown = nil

		parent:SetJumpPower(parent.JumpHeight)
		parent.JumpHeight = nil
		

		if parent:Alive() then
			parent:DrawViewModel(true)
			parent:DrawWorldModel(true)

			local rag = parent:GetRagdollEntity()
			if rag and rag:IsValid() then
				rag:Remove()
			end
		end
	end
end