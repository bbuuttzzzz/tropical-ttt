Tropical Core
=============
Shared components for Garry's Mod 13 gamemodes made by Tropical group
By KLUTZ

SETUP
=====

* Clone repository into Gamemode folder within your new gamemode
* include("tropical-core/init.lua") at the top of the gamemode's init.lua
* include("tropical-core/cl\_init.lua") at the top of the gamemode's cl\_init.lua

LEGAL
=====

certain parts of this project fall under different owners.
Unless otherwise stated, this work falls under the GNU AGPLv3, as described in the
file named "GNU-AGPLv3.txt"

Certain sections of this code is marked as being "noxZS". these are all derivative of
NoxiousNet zombie survival's code (https://github.com/JetBoom/zombiesurvival/)
and falls under William Moodhe's JBGM License, as described in the file named "JGBM.txt"
